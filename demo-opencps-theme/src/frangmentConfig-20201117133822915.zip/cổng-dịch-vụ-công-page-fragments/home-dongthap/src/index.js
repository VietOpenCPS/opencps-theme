var portalUrl = window.themeDisplay.getPortalURL();
$( "#keyword" ).keypress(function( event ) {
  if ( event.which == 13 ) {
    window.location.href = '/web/cong-dich-vu-cong-tinh-dong-thap/kios#/tra-cuu-ho-so-homepage?keyword=' + document.getElementById('keyword').value
  }
});
if (typeof(Storage) !== 'undefined') {
  let userType = sessionStorage.getItem('userLogout');
  if (String(userType) === 'employee') {
    window.location.href = '/web/mot-cua-tinh-dong-thap'
  }
  sessionStorage.removeItem('userLogout');
};
if (window.themeDisplay.isSignedIn() && window.location.href === portalUrl + '/web/cong-dich-vu-cong-tinh-dong-thap') {
  window.location.href = portalUrl + '/web/cong-dich-vu-cong-tinh-dong-thap/dich-vu-cong'
}
if (window.themeDisplay.isSignedIn() && window.location.hash.indexOf('#/add-dvc/') === 0) {
  window.location.href = window.location.origin + window.location.pathname + '/dich-vu-cong/' + window.location.hash
}
if (window.themeDisplay.isSignedIn()) {
  $("#submit-dossier").html('<a href="/web/cong-dich-vu-cong-tinh-dong-thap/thu-tuc-hanh-chinh" class="btn-submit">Nộp hồ sơ trực tuyến <i class="fa fa-upload"></i></a>')
} else {
  $("#submit-dossier").html(`<button class="btn-submit" onclick="alert('Vui lòng đăng nhập để nộp hồ sơ trực tuyến')">Nộp hồ sơ trực tuyến <i class="fa fa-upload"></i></button>`)
}
// 
let textInfo = `Bạn đang đăng nhập bằng tài khoản <span style="color: yellow">${window.themeDisplay.getUserName()}</span>`;
$("#loginInfo").html(textInfo);
var getResponseHeaders = function(xhr, key) {
  let value = ""
	let headers = xhr.getAllResponseHeaders("Content-Type").split("\n")
	headers.forEach(function (header) {
		header = header.split(": ");
		let keyHeader = header[0];
		if (keyHeader === key) {
			value = header[1]
		}
	});
  return value
}
var doLogin = function(){
	let userName = $("#userName").val();
	let password = $("#password").val();
  $.ajax({
    url: '/o/v1/opencps/login',
	data: {},
    type: 'POST',
    async: false,
    headers: {
      'Authorization': 'BASIC ' + window.btoa(userName + ":" + password)
    },
    success: function (result, status, xhr) {
		if (result) {
			if (typeof(Storage) !== 'undefined') {
			  let token = getResponseHeaders(xhr,"jwt-token")
			  localStorage.setItem('jwt_token', token)
			}
			let url = window.themeDisplay.getSiteAdminURL().split('/~')[0].replace('group','web');
			if (result !== '' && result !== 'ok') {
			  if (result === 'pending') {
				window.location.href = url +
				"/register#/xac-thuc-tai-khoan?active_user_id=" + window.themeDisplay.getUserId() +
				  "&redirectURL=" + url
			  } else {
				window.location.href = result
			  }
			} else if (result === 'ok') {
			  window.location.href = url
			} else {
			  alert("Tên đăng nhập hoặc mật khẩu không chính xác")
			}
		}
    },
    error: function (xhr) {
      alert("Tên đăng nhập hoặc mật khẩu không chính xác")
    }
  })
};
$("#submitLogin").bind( "click", function() {
  if (userName && password) {
    doLogin()
  } else {
    alert("Vui lòng nhập đầy đủ thông tin đăng nhập")
  }
});
$("#submitSign").bind( "click", function() {
  window.location.href = "/web/cong-dich-vu-cong-tinh-dong-thap/register#/"
});
// 
$( "#password" ).keypress(function( event ) {
  if ( event.which == 13 ) {
    doLogin()
  }
});
// 
var yearReport = (new Date()).getFullYear()
$("#title-report").html("Tình hình xử lý hồ sơ " + yearReport)
// Data report1
var block1;
$('#receivedCount').html("0");
$('#undueCount').html("0");
$('#releaseCount').html("0");
$('#processingCount').html("0");
$('#countPercent').html("0%")
var getBlock1 = function(){
  $.ajax({
    url: '/o/rest/statistics?domain=total&agency=total&month=0&year=' + yearReport,
    dataType: 'json',
    type: 'GET',
    async: false,
    headers: {
      'groupId': window.themeDisplay ? window.themeDisplay.getScopeGroupId(): ''
    },
    success: function (result) {
      if (result.data) {
        block1 = result.data;
        console.log(block1)
        $('#receivedCount').html(block1[0].receivedCount);
        $('#undueCount').html(block1[0].receivedCount);
        $('#releaseCount').html(block1[0].releaseCount);
        $('#processingCount').html(block1[0].processingCount);
        $('#countPercent').html(block1[0].ontimePercentage+"%")
      }
    },
    error: function (xhr) {
      
    }
  })

}
getBlock1();