var getOAId = "2240228653918087703"

    window.followCallBack = function followCallBack(zResponse) {
      console.log("followCallBack", zResponse)
      var search = window.location.search ? window.location.search : "?"
      var urlZalo = "http://kiemthu.mt.gov.vn:9002/o/zalohookk" + search +
        "&fromuid=" + zResponse.userId + "&payload=" + window.location.search +
        "&event=addPhone&oaid=" + getOAId
      
      $.ajax({
        type: "POST",
        url: urlZalo,
        data: {},
        success: function (ress) {
        	console.log('ok')
        },
          error: function (err) {
        	console.log(err)
        }
      });
      
    }

    function appendData() {

      $("#main-zalo-wrapper").append(`

      <div class="zalo-wrapper">
        <div class="step-1">
          <label>Bước 1: Quan tâm Zalo</label>
          <div>
            (Nếu chưa quan tâm hãy ấn nút <div class="zalo-follow-only-button" data-oaid="${getOAId}" data-callback="followCallBack"></div>)
          </div>
        </div>
        <div class="step-2">
          <label>Bước 2: Tra cứu trạng thái hồ ssơ</label>
          <div>
            (Soạn tin: tracuu&lt;khoảng cách&gt;Ma_ho_so&lt;khoảng cách&gt;Ma_tra_cuu)
          </div>
        </div>
        <!--<div class="step-3">
          <label>Bước 3: Cập nhật lại số điện thoại</label>
          <div>
            (Soạn tin: update&lt;khoảng cách&gt;&lt;SĐT&gt;)
          </div>
        </div>-->
        <div class="zalo-follow-button" data-oaid="${getOAId}" data-cover="no" data-article="0" data-width="500" data-height="410" data-callback="followCallBack" style="height:275px;"></div>
      </div>

      <div class="zalo-chat-widget" data-oaid="${getOAId}" data-welcome-message="Hệ thống dịch vụ công rất vui khi được hỗ trợ bạn!" data-autopopup="0" data-width="350" data-height="420"></div>

      `)

    }

    window.$(document).ready(function () {

      appendData()

    })