// function renderMap(i) {
//     var mapTemp = `<iframe src="${contactData[i]['srcMap']}" width="100%" height="350" frameborder="0" allowfullscreen style="border: 1px solid #ddd;"></iframe>`;
//     $("#mapContent").html(mapTemp);
// };
var imageDefault = 'https://img.icons8.com/ultraviolet/80/000000/worldwide-location.png';
var contactData = [
    {
      agencyName : 'Bộ phận một cửa Khối cơ quan bộ',
      imageAgency: 'http://kiemthu.mt.gov.vn:9002/o/kiemthuduongbo-theme/images/img-KhoiCQBo.png',
      address: 'Số 80 Trần Hưng Đạo, Quận Hoàn Kiếm, Hà Nội',
      telNo: '',
      fax: '',
      email: '',
      srcMap: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.232076366779!2d105.84384931472458!3d21.02339809333774!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ab9165a22631%3A0x411cc4f4148af4ea!2zQuG7mSBHaWFvIHRow7RuZyBW4bqtbiB04bqjaQ!5e0!3m2!1svi!2s!4v1554808005957!5m2!1svi!2s'
    },
    {
      agencyName : 'Bộ phận một cửa Tổng Cục Đường bộ Việt Nam',
      imageAgency: 'http://kiemthu.mt.gov.vn:9002/o/kiemthuduongbo-theme/images/img-TongcucDB.png',
      address: 'Lô D20, Khu đô thị Cầu Giấy, Hà Nội',
      telNo: '04.3.857.1444',
      fax: '04.3.857.1440',
      email: 'tcdbvn@drvn.gov.vn',
      srcMap: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.0869287397804!2d105.78098661472463!3d21.02920749313938!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ac828b7c0203%3A0xc03bdc14957ee0f3!2zVOG7lW5nIEPhu6VjIMSQxrDhu51uZyBC4buZIFZp4buHdCBOYW0!5e0!3m2!1svi!2s!4v1554894468107!5m2!1svi!2s'
    },
    {
      agencyName : 'Bộ phận một cửa Cục Đường sắt Việt Nam',
      imageAgency: 'http://kiemthu.mt.gov.vn:9002/o/kiemthuduongbo-theme/images/img-CucDS.png',
      address: '120 Lê Duẩn, quận Hoàn Kiếm, TP. Hà Nội',
      telNo: '04.3.942.7545',
      fax: '04.3.942.7551',
      email: 'cucduongsat@mt.gov.vn',
      srcMap: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.2425460828786!2d105.84369781472452!3d21.02297899335192!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ab917087edbf%3A0x8ef5bee8769189a4!2zQ-G7pWMgxJDGsOG7nW5nIFPhuq90IFZp4buHdCBOYW0!5e0!3m2!1svi!2s!4v1554894349471!5m2!1svi!2s'
    },
    {
      agencyName : 'Bộ phận một cửa Cục Đường thủy nội địa Việt Nam',
      imageAgency: 'http://kiemthu.mt.gov.vn:9002/o/kiemthuduongbo-theme/images/img-CucDTND.png',
      address: 'Số 4 Tôn Thất Thuyết, Dịch Vọng Hậu, Cầu Giấy, Hà Nội',
      telNo: '',
      fax: '',
      email: '',
      srcMap: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.1279129501113!2d105.78313871472454!3d21.027567293195442!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ab4daea68305%3A0x99ddc1602863fae6!2zQ-G7pWMgxJDGsOG7nW5nIHRo4buneSBu4buZaSDEkeG7i2EgVmnhu4d0IE5hbQ!5e0!3m2!1svi!2s!4v1554894541322!5m2!1svi!2s'
    },
    {
      agencyName : 'Bộ phận một cửa Cục Hàng hải Việt Nam',
      imageAgency: 'http://kiemthu.mt.gov.vn:9002/o/kiemthuduongbo-theme/images/img-CucHH.png',
      address: 'Số 8 Phạm Hùng, P. Mai Dịch, Quận Cầu Giấy, Hà Nội',
	  telNo: '(024)37683065',
      fax: '(024)37683058',
      email: 'cuchhvn@vinamarine.gov.vn',
      srcMap: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.0001451854228!2d105.77734991472474!3d21.032680193020845!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x313454b4fe67d075%3A0xf5193ada7753f089!2zQ-G7pWMgaMOgbmcgaOG6o2kgVmnhu4d0IE5hbQ!5e0!3m2!1svi!2s!4v1554894578141!5m2!1svi!2s'
    },
    {
      agencyName : 'Bộ phận một cửa Cục Hàng không Việt Nam',
      imageAgency: 'http://kiemthu.mt.gov.vn:9002/o/kiemthuduongbo-theme/images/img-CucHK.png',
      address: 'Số 119 Nguyễn Sơn, Quận Long Biên, Hà Nội',
      telNo: '',
      fax: '',
      email: '',
      srcMap: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3723.677078832225!2d105.87917121472486!3d21.04560309257943!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135a97eae6fbf59%3A0x28e92142bc89d03b!2zQ-G7pWMgSMOgbmcga2jDtG5nIFZp4buHdCBOYW0!5e0!3m2!1svi!2s!4v1554894633693!5m2!1svi!2s'
    },
    {
      agencyName : 'Bộ phận một cửa Cục Đăng kiểm Việt Nam',
      imageAgency: 'http://kiemthu.mt.gov.vn:9002/o/kiemthuduongbo-theme/images/img-CucDK.png',
      address: 'Số 18 Phạm Hùng, P. Mỹ Đình 2, Quận Nam Từ Liêm, Hà Nội',
      telNo: '04.3.768.4715',
      fax: '04.3.768.4779',
      email: 'vr-id@vr.org.vn',
      srcMap: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.0844723888076!2d105.77633071472457!3d21.029305793136!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x313454b3af0b245b%3A0xf077a1441bab33e5!2zQ-G7pWMgxJDEg25nIGtp4buDbSBWaeG7h3QgTmFt!5e0!3m2!1svi!2s!4v1554894663590!5m2!1svi!2s'
    },
    {
      agencyName : 'Bộ phận hỗ trợ kỹ thuật - Trung tâm CNTT Bộ GTVT',
      imageAgency: 'http://kiemthu.mt.gov.vn:9002/o/kiemthuduongbo-theme/images/img-CucQLXD.png',
      address: 'Số 80 Trần Hưng Đạo, Quận Hoàn Kiếm, Hà Nội',
      telNo: '(024)3.822 2979',
      fax: '024)3.822.106',
      email: 'bophanhotro@mt.gov.vn',
      srcMap: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.232076366779!2d105.84384931472458!3d21.02339809333774!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ab9165a22631%3A0x411cc4f4148af4ea!2zQuG7mSBHaWFvIHRow7RuZyBW4bqtbiB04bqjaQ!5e0!3m2!1svi!2s!4v1554808005957!5m2!1svi!2s'
    }
    
  ];
  
  var htmlRender = ''
  for (var i = 0; i < contactData.length; i++) {
    htmlRender += `
    <div class="flex xs12 sm6 px-2 py-2 itemContent" onclick="$('#mapContent')[0].src = '${contactData[i]['srcMap']}'">
      <div class="layout wrap">
        <div class="flex image-contact" >
          <div class="mt-1 image" style="background-image: url('${contactData[i]['imageAgency'] ? contactData[i]['imageAgency'] : imageDefault}');">
          </div>
        </div>
        <div class="flex px-2 detail-contact">
          <div class="text-bold blue-text mr-2">${contactData[i]['agencyName']}</div>
          <div class="mt-1">
            <span class="blue-text mr-2"><i class="fas fa-map-marked-alt"></i> </span>
            <span> ${contactData[i]['address']}</span>
          </div>
          <div class="mt-1 ${contactData[i]['telNo'] ? '' : 'd-none'}">
            <span class="blue-text mr-2"><i class="fas fa-phone"></i> </span>
            <span> ${contactData[i]['telNo']}</span> - <span>Fax: ${contactData[i]['fax']}</span>
          </div>
          <div class="mt-1 ${contactData[i]['email'] ? '' : 'd-none'}">
            <span class="blue-text mr-2"><i class="far fa-envelope"></i> </span>
            <span> ${contactData[i]['email']}</span>
          </div>
        </div>
      </div>
    </div>
    `
  }
  $('#htmlRender').html(htmlRender)