$(function() {
    var toc = $("#toc").tocify({
        selectors: "h2,h3"
    }).data("toc-tocify");
});

$(window).scroll(function(){
	$('.manual-wrapper .tocify-subheader > li').each(function() {
	  if ($('.manual-wrapper .tocify-subheader > li').hasClass('active')){
		console.log("true");
		$('.manual-wrapper .tocify-subheader > li').parent().prev().addClass('sub-active');
	  } else {
		console.log("false");
		$('.manual-wrapper .tocify-subheader > li').parent().prev().removeClass('sub-active');
	  }
	});
	
	var scroll = $(window).scrollTop();
  if (scroll >= 175) {
    $(".manual-nav").addClass("dynamic-fix-top");
  } else {
    $(".manual-nav").removeClass("dynamic-fix-top");
  }
});