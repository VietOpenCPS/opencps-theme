$(function() {
    var toc = $("#toc").tocify({
        selectors: "h2,h3"
    }).data("toc-tocify");
});

$(window).scroll(function(){
	$('.manual-wrapper .tocify-subheader > li').each(function() {
	  	if ($('.manual-wrapper .tocify-subheader > li').hasClass('active')){
			$('.manual-wrapper .tocify-subheader > li').parent().prev().addClass('sub-active');
	  	} else {
			$('.manual-wrapper .tocify-subheader > li').parent().prev().removeClass('sub-active');
	  	}
	});

	$('.box-wrapper .box-header a').click(function(e) {
		e.preventDefault();
		$(this).parent().siblings().removeClass('active');
		$(this).parent().addClass('active');
	    $(this).parent().parent().parent().next().find('.targetDiv').hide();
	    $('.box-wrapper .box-content #box' + $(this).attr('target')).show();
	});
});