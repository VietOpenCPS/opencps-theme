$(document).ready(function(){
  $( "#keyword" ).keypress(function( event ) {
  if ( event.which == 13 ) {
    window.location.href = '/web/bo-quoc-phong/tra-cuu-ho-so#/?dossierNo=' + document.getElementById('keyword').value
  }
});
  $("#submit-dossier").html('<a href="/web/bo-quoc-phong/thu-tuc-hanh-chinh" class="btn-submit">Nộp hồ sơ trực tuyến&nbsp;&nbsp;<i class="fa fa-upload"></i></a>')

// SSO Cổng DVC Quốc gia
	// SSO Cổng DVC Quốc gia
	var pathNameSet = "/web/bo-quoc-phong"
	var dataObj = "";
	var getSearchParams =function (prams, key) {
		let value = ""
		let headers = prams.split("&")
		headers.forEach(function (header) {
			header = header.split("=");
			let keyHeader = header[0];
			if (keyHeader === key) {
			  value = header[1]
			}
		});
		return value
	};

	var doChangeEmail = function(oldEmailIn, newEmailIn, techIdIn){
		if (newEmailIn) {
			$.ajax({
				url: '/o/rest/v2/dvcqgsso/changeemail?oldEmail=' + oldEmailIn + '&newEmail=' + newEmailIn + '&techId=' + techIdIn,
				data: {},
				type: 'POST',
				async: false,
				headers: {
					'groupId': window.themeDisplay.getScopeGroupId(),
					'Token': window.Liferay.authToken
				},
				success: function (result, status, xhr) {
					dataObj.state = 'auth';
					doAuth(dataObj);
					$("html").css("overflow", "");
				  $("body").removeClass("fog");
				  $("#updateEmail").hide();
					setTimeout(function () {
						window.location.reload()
					}, 100)
				},
				error: function (xhr) {
				}
			})
		}
	};
	
	var doLogin = function(dataIn){
		if ($("#userNameLogin").val() && $("#passwordLogin").val()) {
			$.ajaxSetup({
				headers: {
					'groupId': window.themeDisplay.getScopeGroupId(),
					'Token': window.Liferay.authToken,
					'Authorization': 'BASIC ' + window.btoa($("#userNameLogin").val() + ":" + $("#passwordLogin").val())
				}
			});
			$.post('/o/v1/opencps/login')
			.done(function( data ) {
				if (data === 'ok') {
					$("html").css("overflow", "");
					$("body").removeClass("fog");
					$("#mappingUser").hide();
					dataIn.state = 'mapping'
					doAuth(dataIn);
					setTimeout(function () {
						window.location.reload()
					}, 100)
				} else {
					alert('Tên đăng nhập hoặc mật khẩu không chính xác')
				}
				
			})
		}
		
	};
	var doAuth = function(dataIn){

		$.ajaxSetup({
			headers: {
				'groupId': window.themeDisplay.getScopeGroupId(),
				'Token': window.Liferay.authToken,
				'Content-Type': 'application/json'
			}
		});
		$.post('/o/rest/v2/dvcqgsso/auth', JSON.stringify(dataIn))
		.done(function() {				
		})
		
	};
	
	var cancelChange = function () {
		window.location.href = window.location.origin + window.location.pathname
	}
	var searchParams = window.location.href.split("?");
	if (searchParams[1]) {
		var dataDVCQG = decodeURIComponent(String(getSearchParams(searchParams[1], "data")));
		if (dataDVCQG) {
			dataObj = JSON.parse(atob(dataDVCQG));
			if (dataObj && dataObj.hasOwnProperty('state') && dataObj.state === 'create') {
				$("#newEmail").val(dataObj['ThuDienTu'] ? dataObj['ThuDienTu'] : '');
				$("html").css("overflow", "hidden !important");
				$("body").addClass("fog");
				$("#updateEmail").show();
				//show dialog
				$( "#submit" ).click(function() {
				  doChangeEmail(dataObj['TechID'] + '@dvcqg.gov.vn', $("#newEmail").val(), dataObj['TechID'])
				});
				$( "#cancel" ).click(function() {
				  $("html").css("overflow", "");
				  $("body").removeClass("fog");
				  $("#updateEmail").hide();
				  cancelChange()
				});
				return
			}
			if (dataObj && dataObj.hasOwnProperty('userId') && String(dataObj.userId) === '0' && !window.themeDisplay.isSignedIn()) {
				$("html").css("overflow", "hidden !important");
				$("body").addClass("fog");
				$("#mappingUser").show();
				//show dialog
				$( "#submitLogin" ).click(function() {
				  doLogin(dataObj)
				});
				$( "#cancelLogin" ).click(function() {
				  $("html").css("overflow", "");
				  $("body").removeClass("fog");
				  $("#mappingUser").hide();
				  cancelChange()
				});
				return
			}
		}
	} else {
		
	}
	var portalUrl = window.themeDisplay.getPortalURL();
	if (window.themeDisplay.isSignedIn() && (window.location.href === portalUrl + pathNameSet || window.location.href.indexOf(portalUrl + pathNameSet + '#/login-dichvucong') === 0)) {
		$("html").css("overflow", "");
		$("body").removeClass("fog");
		$("#mappingUser").hide();
		$("#updateEmail").hide();
		window.location.href = portalUrl + pathNameSet + '/dich-vu-cong'
	}
	// 
	if (window.themeDisplay.isSignedIn() && window.location.href.indexOf(portalUrl + pathNameSet + '#/thu-tuc-hanh-chinh/') === 0) {
		$("html").css("overflow", "");
		$("body").removeClass("fog");
		$("#mappingUser").hide();
		$("#updateEmail").hide();
	  window.location.href = portalUrl + pathNameSet + '/thu-tuc-hanh-chinh' + window.location.hash
	}
// 
if (window.themeDisplay.isSignedIn() && window.location.hash.indexOf('#/add-dvc/') === 0) {
  window.location.href = window.location.origin + window.location.pathname + '/dich-vu-cong/' + window.location.hash
}
// Thống kê
var yearReport = (new Date()).getFullYear()
$("#yearPieChart").val(yearReport);
$("#titleReport2").html("Tình hình xử lý hồ sơ")

// Data report pieChart
var optionsPie = {
    chart: {
        type: 'pie',
        height: '450px',
        width: '400px',
        offsetX: -40,
    },

    labels: ['Trước hạn', 'Đúng hạn','Quá hạn'],
    colors: ['#0b99c8','#1c57ab','#f5b333'],
    series: [0,0,0],
    dataLabels: {
        enabled: true
    },
    legend: {
        position: 'bottom',
        fontSize: '14px',
        horizontalAlign: 'center'
    },
    plotOptions: {
        pie: {
        labels: {
            show: true,
            name: {
                show: true,
                fontSize: '14px',
                fontFamily: 'Roboto, Arial, sans-serif',
                color: undefined,
                offsetY: -6
            },
            value: {
                show: true,
                fontSize: '24px',
                fontFamily: 'Roboto, Arial, sans-serif',
                color: undefined,
                offsetY: 5,
                formatter: function (val, w) {
                let total = w.globals.seriesTotals.reduce((a, b) => {
                    return a + b
                }, 0)
                return ((val/total)*100).toFixed(2)+' %'
                }
            }
            }
        }
    },
    responsive: [{
        breakpoint: 480,
        options: {
        chart: {
            width: 200
        },
        legend: {
            position: 'bottom',
            offsetX: 20
        }
        }
    }],  
    fill: {
        colors: undefined,
        opacity: 1,
        type: 'solid',
        gradient: {
            shade: 'dark',
            type: "horizontal",
            shadeIntensity: 0.5,
            gradientToColors: undefined,
            inverseColors: true,
            opacityFrom: 1,
            opacityTo: 1,
            stops: [0, 50, 100],
            colorStops: []
        },
        image: {
            src: [],
            width: undefined,
            height: undefined
        },
        pattern: {
            style: 'verticalLines',
            width: 6,
            height: 6,
            strokeWidth: 2,
        },
    },
    dataLabels: {
    textAnchor: 'end',
    style: {
        fontSize: '17px',
    },
    dropShadow: {
    
    enabled: false,
    left: 4,
    top: 4,
    opacity: 1
    }
    },
    states: {
        normal: {
            filter: {
                type: 'none',
                value: 0,
            }
        },
        hover: {
            filter: {
                type: 'none',
                value: 0.15,
            }
        },
        active: {
            allowMultipleDataPointsSelection: false,
            filter: {
                type: 'none',
                value: 0.35,
            }
        },
    }
}

var getReportPieChart = function(){
	$("#pieChart").html("")
	$("#titleReport2").html("Tình hình xử lý hồ sơ")
  $.ajax({
    url: '/o/rest/statistics?domain=total&month=0&agency=total&year=' + $("#yearPieChart").val(),
    dataType: 'json',
    type: 'GET',
    async: false,
    headers: {
      'groupId': window.themeDisplay ? window.themeDisplay.getScopeGroupId(): ''
    },
    success: function (result) {
      if (result.data) {
        var dataPie = result.data[0]
        optionsPie['series'][0] = dataPie['betimesCount']
        optionsPie['series'][1] = dataPie['ontimeCount']
        optionsPie['series'][2] = dataPie['overtimeCount']
		    // optionsPie['series'][2] = dataPie['overtimeCount']
		    $("#tong_giai_quyet").html(dataPie['processCount'])
		    $("#da_giai_quyet").html(dataPie['releaseCount'] + dataPie['waitingCount'] + dataPie['cancelledCount'])
		    $("#nhan_trong_ky").html(dataPie['ontimeCount'] + dataPie['betimesCount'])
		    $("#dang_giai_quyet").html(dataPie['processingCount'])
		    // $("#ti_le").html(dataPie['ontimePercentage'] + " %")
			$("#ti_le").html((((dataPie['ontimeCount'] + dataPie['betimesCount'])/dataPie['releaseCount'])*100).toFixed(1) + " %")
      } else {
	      optionsPie['series'][0] = 0
        optionsPie['series'][1] = 0
		    // optionsPie['series'][2] = 0
		    $("#tong_giai_quyet").html('0')
		    $("#da_giai_quyet").html('0')
		    $("#nhan_trong_ky").html('0')
		    $("#dang_giai_quyet").html('0')
		    $("#ti_le").html("0 %")
	    }
      var chart = new ApexCharts(
        document.querySelector("#pieChart"),
        optionsPie
      )
      chart.render()
    },
    error: function (xhr) {
      optionsPie['series'][0] = 0
      optionsPie['series'][1] = 0
	   // optionsPie['series'][2] = 0
	    var chart = new ApexCharts(
        document.querySelector("#pieChart"),
        optionsPie
      )
      chart.render()
    }
  })

};
getReportPieChart();

// Data report columnChart
// var optionsColumnChart = {
// 	chart: {
// 		type: 'bar',
// 		height: '350px',
// 		width: '350px',
// 		offsetX: -40,
// 		toolbar: {
// 			show: false
// 		}
// 	},
// 	plotOptions: {
// 		bar: {
// 			horizontal: false,
// 			columnWidth: '40%',
// 			// endingShape: 'rounded'
// 		},
// 	},
// 	dataLabels: {
// 		enabled: false
// 	},
// 	// stroke: {
// 	// 	show: true,
// 	// 	width: 2,
// 	// 	colors: ['transparent']
// 	// },
// 	colors: ['#0b99c8', '#1c57ab', '#cae538'],
// 	series: [{
// 		data: [0, 0, 0]
// 	}],
// 	xaxis: {
// 		categories: ['Đúng hạn', 'Quá hạn', 'Trễ hạn'],
// 	},
// 	tooltip: {
// 		y: {
// 			formatter: function (val) {
// 				return val
// 			}
// 		}
// 	}
// };
var optionsColumnChart = {
    series: [{
        data: [0, 0, 0]
    }],
    chart: {
        height: 450,
        type: 'bar',
        events: {
        click: function(chart, w, e) {
            // console.log(chart, w, e)
        }
        }
    },
    colors: ['#0b99c8', '#1c57ab','#f5b333'],
    plotOptions: {
        bar: {
        columnWidth: '45%',
        distributed: true
        }
    },
    dataLabels: {
        enabled: false
    },
    legend: {
        show: false
    },
    xaxis: {
        categories: [
            'Tổng giải quyết',
            'Đã giải quyết',
            'Đang giải quyết',
        ],
        labels: {
        style: {
            colors: ['#000000', '#000000', '#000000'],
            fontSize: '14px'
        }
        }
    },
    yaxis: {
        labels: {
            style:{
                fontSize: '14px'
            }
        }
    },
    fill: {
        colors: undefined,
        opacity: 1,
        type: 'solid',
        gradient: {
            shade: 'dark',
            type: "horizontal",
            shadeIntensity: 0.5,
            gradientToColors: undefined,
            inverseColors: true,
            opacityFrom: 1,
            opacityTo: 1,
            stops: [0, 50, 100],
            colorStops: []
        },
        image: {
            src: [],
            width: undefined,
            height: undefined
        },
        pattern: {
            style: 'verticalLines',
            width: 6,
            height: 6,
            strokeWidth: 2,
        },
    },
    states: {
        normal: {
            filter: {
                type: 'none',
                value: 0,
            }
        },
        hover: {
            filter: {
                type: 'none',
                value: 0.15,
            }
        },
        active: {
            allowMultipleDataPointsSelection: false,
            filter: {
                type: 'none',
                value: 0.35,
            }
        },
    }
};
var getReportColumnChart = function(){
	$("#columnChart2").html("")
	$.ajax({
    // url: '/o/rest/statistics?agency=total&year=' + $("#yearPieChart").val(),
    url: '/o/rest/statistics?domain=total&month=0&agency=total&year=' + $("#yearColumnChart").val(),
    dataType: 'json',
    type: 'GET',
    async: false,
    headers: {
      'groupId': window.themeDisplay ? window.themeDisplay.getScopeGroupId(): ''
    },
    success: function (result) {
      if (result.data) {
        var dataQuater = result.data
        var dataColumn = result.data[0]
        optionsColumnChart['series'][0]['data'] = [dataColumn['processCount'],dataColumn['ontimeCount'] + dataColumn['betimesCount'],dataColumn['processingCount']]
        // optionsColumnChart['series'][0] = dataColumn['betimesCount'] + dataColumn['ontimeCount']
        // optionsColumnChart['series'][1] = dataColumn['overtimeCount']
        // optionsColumnChart['series'][2] = dataColumn['overtimeCount']
        // optionsColumnChart['series'][1]['data'] = dataColumn['overtimeCount']
	    // optionsColumnChart['series'][2]['data'] = dataColumn['overtimeCount']
        // optionsColumnChart.series[0]['data'] = [0,0,0,0]
        // optionsColumnChart.series[1]['data'] = [0,0,0,0]
        // optionsColumnChart.series[2]['data'] = [0,0,0,0]
        // for (var index in dataQuater) {
        // 	if (dataQuater[index]['domainCode'] && dataQuater[index]['month'] && dataQuater[index]['month'] <= 3) {
        // 		optionsColumnChart.series[0]['data'][0] += dataQuater[index]['receivedCount'];
        // 		optionsColumnChart.series[1]['data'][0] += dataQuater[index]['ontimeCount'];
        // 		optionsColumnChart.series[2]['data'][0] += dataQuater[index]['overdueCount'];
        // 	} else if (dataQuater[index]['domainCode'] && dataQuater[index]['month'] && dataQuater[index]['month'] >=4 && dataQuater[index]['month'] <= 6) {
        // 		optionsColumnChart.series[0]['data'][1] += dataQuater[index]['receivedCount'];
        // 		optionsColumnChart.series[1]['data'][1] += dataQuater[index]['ontimeCount'];
        // 		optionsColumnChart.series[2]['data'][1] += dataQuater[index]['overdueCount']
        // 	} else if (dataQuater[index]['domainCode'] && dataQuater[index]['month'] && dataQuater[index]['month'] >=7 && dataQuater[index]['month'] <= 9) {
        // 		optionsColumnChart.series[0]['data'][2] += dataQuater[index]['receivedCount'];
        // 		optionsColumnChart.series[1]['data'][2] += dataQuater[index]['ontimeCount'];
        // 		optionsColumnChart.series[2]['data'][2] += dataQuater[index]['overdueCount']
        // 	} else if (dataQuater[index]['domainCode'] && dataQuater[index]['month'] && dataQuater[index]['month'] >=10 && dataQuater[index]['month'] <= 12) {
        // 		optionsColumnChart.series[0]['data'][3] += dataQuater[index]['receivedCount'];
        // 		optionsColumnChart.series[1]['data'][3] += dataQuater[index]['ontimeCount'];
        // 		optionsColumnChart.series[2]['data'][3] += dataQuater[index]['overdueCount']
        // 	}
        // }
		    setTimeout(function () {
      		var chartColumn = new ApexCharts(
      			document.querySelector("#columnChart2"),
      			optionsColumnChart
      		  );
      		chartColumn.render();
      	  }, 300)
      } else {
		optionsColumnChart.series = [{
			data: [0, 0, 0]
		}]
	  }
    //   setTimeout(function () {
    // 		var chartColumn = new ApexCharts(
    // 			document.querySelector("#columnChart2"),
    // 			optionsColumnChart
    // 		  );
    // 		chartColumn.render();
    // 	  }, 300)
          
        },
    error: function (xhr) {
      optionsColumnChart.series[0]['data'] = [400,650,349];
      setTimeout(function () {
  		var chartColumn = new ApexCharts(
  			document.querySelector("#columnChart2"),
  			optionsColumnChart
  		  );
  		chartColumn.render();
  	  }, 300)
    }
  })
};
 getReportColumnChart();
// 
var changeYear1 = function () {
  getReportPieChart();
}
var changeYear2 = function () {
    getReportColumnChart();
}

})
var changeYear1 = function () {
    getReportPieChart();
}
var changeYear2 = function () {
    getReportColumnChart();
}