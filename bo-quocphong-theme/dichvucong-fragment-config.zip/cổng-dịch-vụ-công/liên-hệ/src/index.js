// function renderMap(i) {
//     var mapTemp = `<iframe src="${contactData[i]['srcMap']}" width="100%" height="350" frameborder="0" allowfullscreen style="border: 1px solid #ddd;"></iframe>`;
//     $("#mapContent").html(mapTemp);
// };
var contactData = [
    {
      agencyName : 'Trụ sở tiếp công dân',
      imageAgency: 'documents/272435/450501/quoc-huy2x.png/174cca91-68fc-7a00-6be4-6832363a4296?t=1585121555784',
      address: '<b>Trụ sở tiếp dân Bộ Quốc Phòng</b> </br>Km 11, quốc lộ 32, đường Cầu Diễn, phường Phúc Diễn, quận Bắc Từ Liêm, thành phố Hà Nội',
      telNo: '069.553215',
      email: 'info@mod.gov.vn',
      srcMap: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3723.9687117794383!2d105.84050051464862!3d21.033937885995567!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135abbd18b50503%3A0x4c4168cd20063476!2sMinistry%20of%20Defense!5e0!3m2!1sen!2s!4v1578307427431!5m2!1sen!2s'
    },
         ];
    var htmlRender = ''
  for (var i = 0; i < contactData.length; i++) {
    htmlRender += `
    <div class="flex itemContent" onclick="$('#mapContent')[0].src = '${contactData[i]['srcMap']}'">
      <div class="layout wrap">
        <div class="flex image-contact" >
          <div class="mt-1 image" style="background-image: url('${contactData[i]['imageAgency'] ? contactData[i]['imageAgency'] : imageDefault}');">
          </div>
        </div>
        <div class="flex px-2 detail-contact">
          <div class="text-bold blue-text mr-2">${contactData[i]['agencyName']}</div>
          <div class="mt-1">
            <span class="blue-text mr-2"><i class="fas fa-map-marked-alt"></i> </span>
            <span> ${contactData[i]['address']}</span>
          </div>
          <div class="mt-1 ${contactData[i]['telNo'] ? '' : 'd-none'}">
            <span class="blue-text mr-2"><i class="fas fa-phone"></i> </span>
            <span> ${contactData[i]['telNo']}</span>
          </div>
          <div class="mt-1 ${contactData[i]['email'] ? '' : 'd-none'}">
            <span class="blue-text mr-2"><i class="far fa-envelope"></i> </span>
            <span> ${contactData[i]['email']}</span>
          </div>
          <div class="mt-1 ${contactData[i]['web'] ? '' : 'd-none'}">
            <span class="mr-2">Website:</span>
            <a href="${contactData[i]['web']}"> ${contactData[i]['web']}</a>
          </div>
        </div>
      </div>
    </div>
    `
  }
  $('#htmlRender').html(htmlRender)