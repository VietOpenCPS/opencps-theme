// function renderMap(i) {
//     var mapTemp = `<iframe src="${contactData[i]['srcMap']}" width="100%" height="350" frameborder="0" allowfullscreen style="border: 1px solid #ddd;"></iframe>`;
//     $("#mapContent").html(mapTemp);
// };
var contactData = [
    {
      agencyName : 'Ban quản lý khu công nghệ cao Hòa Lạc',
      imageAgency: 'documents/272435/450501/quoc-huy2x.png/174cca91-68fc-7a00-6be4-6832363a4296?t=1585121555784',
      address: 'Km 29 - Đại lộ Thăng Long- Thạch Thất - Hà Nội',
      telNo: '(84 24) 6326 9295',
      email: 'info@hhtp.gov.vn',
      srcMap: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d19136.556200069346!2d105.52431638491812!3d21.00215973942945!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31345bb0e775bfc9%3A0x6c07802835338f8f!2zS2h1IEPDtG5nIE5naOG7hyBDYW8gSMOyYSBM4bqhYw!5e0!3m2!1svi!2s!4v1603097104749!5m2!1svi!2s'
    },
         ];
    var htmlRender = ''
  for (var i = 0; i < contactData.length; i++) {
    htmlRender += `
    <div class="flex itemContent" onclick="$('#mapContent')[0].src = '${contactData[i]['srcMap']}'">
      <div class="layout wrap">
        <div class="flex image-contact" >
          <div class="mt-1 image" style="background-image: url('${contactData[i]['imageAgency'] ? contactData[i]['imageAgency'] : imageDefault}');">
          </div>
        </div>
        <div class="flex px-2 detail-contact">
          <div class="text-bold blue-text mr-2">${contactData[i]['agencyName']}</div>
          <div class="mt-1">
            <span class="blue-text mr-2"><i class="fas fa-map-marked-alt"></i> </span>
            <span> ${contactData[i]['address']}</span>
          </div>
          <div class="mt-1 ${contactData[i]['telNo'] ? '' : 'd-none'}">
            <span class="blue-text mr-2"><i class="fas fa-phone"></i> </span>
            <span> ${contactData[i]['telNo']}</span>
          </div>
          <div class="mt-1 ${contactData[i]['email'] ? '' : 'd-none'}">
            <span class="blue-text mr-2"><i class="far fa-envelope"></i> </span>
            <span> ${contactData[i]['email']}</span>
          </div>
          <div class="mt-1 ${contactData[i]['web'] ? '' : 'd-none'}">
            <span class="mr-2">Website:</span>
            <a href="${contactData[i]['web']}"> ${contactData[i]['web']}</a>
          </div>
        </div>
      </div>
    </div>
    `
  }
  $('#htmlRender').html(htmlRender)