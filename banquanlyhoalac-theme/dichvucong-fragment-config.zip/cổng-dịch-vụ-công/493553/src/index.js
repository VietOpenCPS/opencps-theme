$(document).ready(function () {
    var portalUrl = window.themeDisplay.getPortalURL();
    // SSO Cổng DVC Quốc gia
    var pathNameSet = "/web/dich-vu-cong-hoa-lac"
    var dataObj = "";
    var getSearchParams = function (prams, key) {
        let value = ""
        let headers = prams.split("&")
        headers.forEach(function (header) {
            header = header.split("=");
            let keyHeader = header[0];
            if (keyHeader === key) {
                value = header[1]
            }
        });
        return value
    };

    var doChangeEmail = function (oldEmailIn, newEmailIn, techIdIn) {
        if (newEmailIn) {
            $.ajax({
                url: '/o/rest/v2/dvcqgsso/changeemail?oldEmail=' + oldEmailIn + '&newEmail=' + newEmailIn + '&techId=' + techIdIn,
                data: {},
                type: 'POST',
                async: false,
                headers: {
                    'groupId': window.themeDisplay.getScopeGroupId(),
                    'Token': window.Liferay.authToken
                },
                success: function (result, status, xhr) {
                    dataObj.state = 'auth';
                    doAuth(dataObj);
                    $("html").css("overflow", "");
                    $("body").removeClass("fog");
                    $("#updateEmail").hide();
                    var portalUrl = window.themeDisplay.getPortalURL();
                    if (window.themeDisplay.isSignedIn() && (window.location.href === portalUrl + pathNameSet || window.location.href.indexOf(portalUrl + pathNameSet + '#/login-dichvucong') === 0)) {
                        window.location.href = portalUrl + pathNameSet + '/dich-vu-cong'
                    }
                    // 
                    if (window.themeDisplay.isSignedIn() && window.location.href.indexOf(portalUrl + pathNameSet + '#/thu-tuc-hanh-chinh/') === 0) {
                        window.location.href = portalUrl + pathNameSet + '/thu-tuc-hanh-chinh' + window.location.hash
                    }
                },
                error: function (xhr) {
                }
            })
        }
    };

    var doLogin = function (dataIn) {
        if ($("#userNameLogin").val() && $("#passwordLogin").val()) {
            $.ajaxSetup({
                headers: {
                    'groupId': window.themeDisplay.getScopeGroupId(),
                    'Token': window.Liferay.authToken,
                    'Authorization': 'BASIC ' + window.btoa($("#userNameLogin").val() + ":" + $("#passwordLogin").val())
                }
            });
            $.post('/o/v1/opencps/login')
                .done(function (data) {
                    if (data === 'ok') {
                        $("html").css("overflow", "");
                        $("body").removeClass("fog");
                        $("#mappingUser").hide();
                        dataIn.state = 'mapping'
                        doAuth(dataIn);
                        setTimeout(function () {
                            window.location.reload()
                        }, 100)
                    } else {
                        alert('Tên đăng nhập hoặc mật khẩu không chính xác')
                    }

                })
        }

    };
    var doAuth = function (dataIn) {
        $.ajaxSetup({
            headers: {
                'groupId': window.themeDisplay.getScopeGroupId(),
                'Token': window.Liferay.authToken,
                'Content-Type': 'application/json'
            }
        });
        $.post('/o/rest/v2/dvcqgsso/auth', JSON.stringify(dataIn))
            .done(function () {
            })
    };

    var cancelChange = function () {
        window.location.href = window.location.origin + window.location.pathname
    }
    var searchParams = window.location.href.split("?");
    if (searchParams[1]) {
        var dataDVCQG = decodeURIComponent(String(getSearchParams(searchParams[1], "data")));
        if (dataDVCQG) {
            dataObj = JSON.parse(atob(dataDVCQG));
            if (dataObj && dataObj.hasOwnProperty('state') && dataObj.state === 'create') {
                var oldEmail = dataObj['ThuDienTu'] ? dataObj['ThuDienTu'] : dataObj['TechID'] + '@dvcqg.gov.vn'
                $("#newEmail").val(dataObj['ThuDienTu'] ? dataObj['ThuDienTu'] : '');
                $("html").css("overflow", "hidden !important");
                $("body").addClass("fog");
                $("#updateEmail").show();
                //show dialog
                $("#submit").click(function () {
                    doChangeEmail(dataObj['TechID'] + '@dvcqg.gov.vn', $("#newEmail").val(), dataObj['TechID'])
                });
                $("#cancel").click(function () {
                    $("html").css("overflow", "");
                    $("body").removeClass("fog");
                    $("#updateEmail").hide();
                    cancelChange()
                });
                return
            }
            if (dataObj && dataObj.hasOwnProperty('userId') && String(dataObj.userId) === '0' && !window.themeDisplay.isSignedIn()) {
                $("html").css("overflow", "hidden !important");
                $("body").addClass("fog");
                $("#mappingUser").show();
                //show dialog
                $("#submitLogin").click(function () {
                    doLogin(dataObj)
                });
                $("#cancelLogin").click(function () {
                    $("html").css("overflow", "");
                    $("body").removeClass("fog");
                    $("#mappingUser").hide();
                    cancelChange()
                });
                return
            }
        }
    } else {

    }
    var portalUrl = window.themeDisplay.getPortalURL();
    if (window.themeDisplay.isSignedIn() && (window.location.href === portalUrl + pathNameSet || window.location.href.indexOf(portalUrl + pathNameSet + '#/login-dichvucong') === 0)) {
        $("html").css("overflow", "");
        $("body").removeClass("fog");
        $("#mappingUser").hide();
        $("#updateEmail").hide();
        window.location.href = portalUrl + pathNameSet + '/dich-vu-cong'
    }
    // 
    if (window.themeDisplay.isSignedIn() && window.location.href.indexOf(portalUrl + pathNameSet + '#/thu-tuc-hanh-chinh/') === 0) {
        $("html").css("overflow", "");
        $("body").removeClass("fog");
        $("#mappingUser").hide();
        $("#updateEmail").hide();
        window.location.href = portalUrl + pathNameSet + '/thu-tuc-hanh-chinh' + window.location.hash
    }
    // end SSO DVCQG
    // 

    $("#submit-dossier").html(`<button class="btn-submit">Nộp hồ sơ trực tuyến</button>`)
    $("#submit-dossier button").on("click", function () {
      window.location.href = portalUrl + pathNameSet + '/thu-tuc-hanh-chinh'
    })
    var modalConfirm = function (callback) {
        $("#btn-confirm").on("click", function () {
            $(".modal").css("display", "block")
            $("#backdrop").css({ "display": "block", "opacity": "0.6" })
        });
        $("#modal-btn-yes").on("click", function () {
            callback(true);
            $(".modal").css("display", "none")
            $("#backdrop").css("display", "none")
        });
        $("#modal-btn-no").on("click", function () {
            callback(false);
            $(".modal").css("display", "none")
            $("#backdrop").css("display", "none")
        });
        $("#close-modal").on("click", function () {
            $(".modal").css("display", "none")
            $("#backdrop").css("display", "none")
        });
    };

    modalConfirm(function (confirm) {
        if (confirm) {
            window.location.href = "/web/dich-vu-cong-hoa-lac/dang-ky#/login-dichvucong"
        } else {
            window.location.href = "/web/dich-vu-cong-hoa-lac/dich-vu-cong#/add-dvc/0"
        }
    });
    //
    $("#keyword").keypress(function (event) {
        if (event.which == 13) {
            window.location.href = '/web/dich-vu-cong-hoa-lac/tra-cuu-ho-so#/?dossierNo=' + document.getElementById('keyword').value
        }
    });
    // Data report
    var dataReport;
    var yearReport = (new Date()).getFullYear();
    $('#title-report').html("Tình hình xử lý hồ sơ " + yearReport)
    var getReport = function () {
        $.ajax({
            url: '/o/rest/statistics?domain=total&agency=total&month=0&year=' + yearReport,
            dataType: 'json',
            type: 'GET',
            async: false,
            headers: {
                'groupId': window.themeDisplay ? window.themeDisplay.getScopeGroupId() : ''
            },
            success: function (result) {
                if (result.data) {
                    dataReport = result.data;
                    $('#receivedCount').html(dataReport[0].receivedCount);
                    $('#ontimeCount').html(dataReport[0].ontimeCount + dataReport[0].betimesCount);
                    $('#undueCount').html(dataReport[0].undueCount);
                    $('#betimesCount').html(dataReport[0].betimesCount);
                    $('#overtimeCount').html(dataReport[0].overtimeCount);
                    $('#countPercent').html(dataReport[0].ontimePercentage + "%")
                }
            },
            error: function (xhr) {

            }
        })

    };
    getReport()
})